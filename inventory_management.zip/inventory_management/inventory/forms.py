from django import forms
from .models import Product, Inventory, Order

class ProductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = ['name', 'description', 'price']

    def clean_price(self):
        price = self.cleaned_data.get('price')
        if price <= 0:
            raise forms.ValidationError("Price must be greater than zero.")
        return price

class InventoryForm(forms.ModelForm):
    class Meta:
        model = Inventory
        fields = ['product', 'quantity_in_stock','quantity_reserved','reorder_point']

    def clean(self):
        cleaned_data = super().clean()
        quantity_in_stock = cleaned_data.get('quantity_in_stock')
        reorder_point = cleaned_data.get('reorder_point')
        
        if quantity_in_stock < 0:
            self.add_error('quantity_in_stock', "Quantity in stock cannot be negative.")
        if reorder_point < 0:
            self.add_error('reorder_point', "Reorder point cannot be negative.")
        return cleaned_data
class OrderForm(forms.ModelForm):
    class Meta:
        model = Order
        fields = ['product', 'quantity', 'status']

    def clean_quantity(self):
        quantity = self.cleaned_data.get('quantity')
        if quantity <= 0:
            raise forms.ValidationError("Quantity must be greater than zero.")
        return quantity

from django.urls import path
from . import views

urlpatterns = [
    path('', views.login_view, name='login'),
    path('signup/', views.signup_view, name='signup'),
    path('login/', views.login_view, name='login'),
    path('product_list/', views.product_list, name='product_list'),
    path('add_product/', views.add_product, name='add_product'),
    path('inventory/', views.inventory_list, name='inventory_list'),
    path('add_inventory/', views.add_inventory, name='add_inventory'),
    path('home/', views.home_view, name='home'),
    path('create_order/', views.create_order, name='create_order'),
    path('update_inventory/<int:pk>/', views.update_inventory, name='update_inventory'),
    path('delete_inventory/<int:pk>/', views.delete_inventory, name='delete_inventory'),
    path('inventory_report/', views.inventory_report, name='inventory_report'),
    path('order_list/', views.order_list, name='order_list'),
    path('complete_order/<int:order_id>/', views.complete_order, name='complete_order'),

]

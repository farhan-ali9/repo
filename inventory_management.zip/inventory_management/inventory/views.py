from django.shortcuts import render, get_object_or_404, redirect
from .models import Product, Inventory, Order
from .forms import ProductForm, InventoryForm, OrderForm
from django.contrib.auth import authenticate, login
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.models import User
from django.contrib import messages

def product_list(request):
    products = Product.objects.all()
    return render(request, 'inventory/product_list.html', {'products': products})

def add_product(request):
    if request.method == 'POST':
        form = ProductForm(request.POST)
        if form.is_valid():
            product = form.save(commit=False)  # Save product without committing to the database yet
            low_stock_alert = product.save()  # Save product and check for low stock
            if low_stock_alert:  # If low stock alert is triggered
                messages.warning(request, f"Low Stock Alert: {product.name} - Current stock is {product.quantity_in_stock}. Please restock.")
            return redirect('product_list')
    else:
        form = ProductForm()
    return render(request, 'inventory/add_product.html', {'form': form})

def inventory_list(request):
    inventories = Inventory.objects.all()
    return render(request, 'inventory/inventory_list.html', {'inventories': inventories})

def add_inventory(request):
    if request.method == 'POST':
        form = InventoryForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('inventory_list')
    else:
        form = InventoryForm()
    return render(request, 'inventory/add_inventory.html', {'form': form})

def signup_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']
        # Check if fields are filled
        if username and email and password:
            if User.objects.filter(username=username).exists():
                messages.error(request, 'Username already exists')
            elif User.objects.filter(email=email).exists():
                messages.error(request, 'Email already registered')
            else:
                # Create the user
                user = User.objects.create_user(username=username, email=email, password=password)
                user.save()
                messages.success(request, 'Account created successfully! You can log in now.')
                return redirect('login')
        else:
            messages.error(request, 'All fields are required')
    return render(request, 'registration/signup.html')

def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('home')  # Redirect to the home page after login
        else:
            messages.error(request, 'Invalid username or password')
    else:
        form = AuthenticationForm()
    return render(request, 'registration/login.html', {'form': form})
def update_inventory(request, pk):
    inventory = get_object_or_404(Inventory, pk=pk)
    if request.method == 'POST':
        form = InventoryForm(request.POST, instance=inventory)
        if form.is_valid():
            form.save()
            return redirect('inventory_list')
    else:
        form = InventoryForm(instance=inventory)
    return render(request, 'inventory/update_inventory.html', {'form': form})
def delete_inventory(request, pk):
    inventory = get_object_or_404(Inventory, pk=pk)
    if request.method == 'POST':
        inventory.delete()
        return redirect('inventory_list')
    return render(request, 'inventory/delete_inventory.html', {'inventory': inventory})

def home_view(request):
    return render(request, 'home.html')
def create_order(request):
    if request.method == 'POST':
        form = OrderForm(request.POST)
        if form.is_valid():
            order = form.save(commit=False)
            product = order.product

            # Check stock availability
            if product.quantity_available >= order.quantity:
                # Reserve stock
                product.quantity_available -= order.quantity  # Deduct from available stock
                product.quantity_reserved += order.quantity  # Reserve the quantity for the order
                product.save()

                # Save order as pending
                order.status = 'Pending'
                order.save()

                messages.success(request, 'Order created successfully! Stock reserved.')
                return redirect('order_list')  # Adjust as needed
            else:
                messages.error(request, 'Not enough stock available for this order.')
    else:
        form = OrderForm()

    return render(request, 'inventory/create_order.html', {'form': form})
def inventory_report(request):
    inventories = Inventory.objects.all()
    total_stock = sum([inventory.quantity_in_stock for inventory in inventories])
    total_reserved = sum([inventory.quantity_reserved for inventory in inventories])
    
    return render(request, 'inventory/inventory_report.html', {
        'inventories': inventories,
        'total_stock': total_stock,
        'total_reserved': total_reserved,
    })
def complete_order(request, order_id):
    order = get_object_or_404(Order, id=order_id)
    
    if request.method == 'POST':
        # Update stock based on the completed order
        product = order.product
        product.quantity_reserved -= order.quantity
        product.save()

        # Update order status
        order.status = 'Completed'
        order.save()

        messages.success(request, 'Order completed successfully! Stock updated.')
        return redirect('order_list')

    return render(request, 'inventory/complete_order.html', {'order': order})
def order_list(request):
    orders = Order.objects.all()
    return render(request, 'inventory/order_list.html', {'orders': orders})

from django.db import models
from django.contrib import messages
from django.utils import timezone

class Product(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField()
    price = models.DecimalField(max_digits=10, decimal_places=2)
    quantity_in_stock = models.IntegerField(default=0)
    quantity_reserved = models.IntegerField(default=0)
    quantity_available = models.IntegerField(default=0)

    def save(self, *args, **kwargs):
        self.quantity_available = self.quantity_in_stock - self.quantity_reserved
        super().save(*args, **kwargs)

        try:
            inventory = self.inventories.first()  # Use related_name here
            if inventory and self.quantity_in_stock <= inventory.reorder_point:
                self.show_low_stock_alert(kwargs.get('request'))
        except Inventory.DoesNotExist:
            if kwargs.get('request'):
                messages.warning(kwargs.get('request'), f"{self.name} has no linked inventory.")

    def show_low_stock_alert(self, request):
        if request:
            message = f"Low Stock Alert: {self.name} - Current stock is {self.quantity_in_stock}. Please restock."
            messages.warning(request, message)

    def __str__(self):
        return self.name

class Inventory(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name='inventories')
    quantity_in_stock = models.IntegerField(default=0)
    quantity_reserved = models.IntegerField(default=0)
    reorder_point = models.IntegerField(default=10)

    def __str__(self):
        return f"{self.product.name} - In Stock: {self.quantity_in_stock}"

class Order(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantity = models.IntegerField()
    status = models.CharField(max_length=50, choices=[('Pending', 'Pending'), ('Completed', 'Completed')])

    def __str__(self):
        return f"Order for {self.product.name} - Quantity: {self.quantity}"
class Order(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantity = models.IntegerField()
    status = models.CharField(max_length=50, choices=[('Pending', 'Pending'), ('Completed', 'Completed')])
    date = models.DateTimeField(default=timezone.now)
    def save(self, *args, **kwargs):
        if self.status == 'Completed':
            self.product.quantity_reserved -= self.quantity
            self.product.save()
        elif self.status == 'Pending':
            self.product.quantity_reserved += self.quantity
            self.product.save()

        super().save(*args, **kwargs)

    def __str__(self):
        return f"Order for {self.product.name} - Quantity: {self.quantity}"
